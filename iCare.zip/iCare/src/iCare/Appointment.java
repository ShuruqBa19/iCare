package CPIT305Project;

import java.util.Date;

public class Appointment {

    private Patient Patient;

    private MedicalEmployee MedicalEmployee;

    

    private Date appointmentDate;

    private int appointmentID;

    private boolean available = true;

    public Appointment(Patient Patient, MedicalEmployee MedicalEmployee, Date appointmentDate) {
        this.Patient=Patient;
        this.MedicalEmployee=MedicalEmployee;
        this.appointmentDate=appointmentDate;
        this.appointmentID=generateID();
        
    }

    public void setPatient(Patient Patient) {
      this.Patient=Patient;
    }

    public void setMedicalEmployee(MedicalEmployee MedicalEmployee) {
        this.MedicalEmployee=MedicalEmployee;
    }

    public void setAppointmentDate(Date AppointmentDate) {
      this.appointmentDate=AppointmentDate;
    }

    public void setAppointmentID(int ID) {
       this.appointmentID=ID;
    }

    public void setAvailable(boolean Available) {
       this.available=Available;
               
    }

    public boolean getAvailable() {
       return available;
    }

    public boolean isAvailable() {
       return available==true;
    }

    public int generateID() {
        return (int)(Math.random()*100000);
    }

    public Patient getPatient() {
        return Patient;
    }

    public MedicalEmployee getMedicalEmployee() {
       return MedicalEmployee;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
            }

    public int getID() {
    return appointmentID;
    }
}
